Level 2 Food Hygiene and Safety — UK
Version: 1.0.0 (2025-11-07)

Contents
- data/course.json — course meta
- data/modules.json — modules with objectives
- data/question_bank.json — 180 questions
- slides/*.md — slides per module in Markdown
- illustrations/illustrations.json — prompt bank for graphics

Integration notes
- The JSON is flat and predictable for import.
- Questions include mcq, true_false, scenario_multi. Scenario questions may have multiple correct answers.
- The pass mark is set to 75 percent in course.json. Change as needed.
- Temperature values use typical UK guidance.
- Replace or extend slides in Markdown without changing schema.

Licensing
- You are free to adapt and extend. This pack is original content.