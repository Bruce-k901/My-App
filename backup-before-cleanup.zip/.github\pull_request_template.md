### UI Consistency

- [ ] I’ve reviewed all visual changes against [/docs/UI-Style-Guide.md](../docs/UI-Style-Guide.md)
- [ ] No inline style overrides were used for shared components
- [ ] Component variants follow Button/Input/Card standards
