
Module 5 — Allergens & Allergen Management
Date: 2025-11-07
Duration: ~15 minutes
Interactivity: hotspot label, drag-drop match, branch scenario, quiz

Media:
- images/label_allergen.png (placeholder created)

Components used:
- HotspotRoom
- DragDrop
- BranchScenario

Add "m5" to the course sequence. Outcomes map to L2-5.1..L2-5.5.
