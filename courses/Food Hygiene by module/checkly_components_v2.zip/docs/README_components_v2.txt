
Interactive Component Pack v2
Version: 2025-11-07

Components
- TemperatureDial.tsx
- HandwashSequencer.tsx
- HotspotRoom.tsx
- BranchScenario.tsx
- index.ts barrel exports

Schemas
- accreditation_mapping_schema.json

Media
- media/lottie/*.json placeholders: danger_zone_dial, handwash_steps, storage_hierarchy, cleaning_cycle

Usage
1) Copy 'components' into your project under /courses/components or a shared UI lib.
2) Import from the barrel, eg: import { TemperatureDial } from "@/courses/components";
3) Wire to your page types:
   - 'temperature' pages call <TemperatureDial onDone=(ok)=>ok && next() />
   - 'hotspot' pages call <HotspotRoom ... onDone=(ok)=> ok && next() />
   - 'branch' pages call <BranchScenario ... onDone=(i,ok)=> ok && next() />
4) Replace Lottie placeholders with real design files later; props stay the same.

Accessibility
- Buttons and inputs are keyboard operable.
- Visible focus via browser defaults; customise with Tailwind if needed.
