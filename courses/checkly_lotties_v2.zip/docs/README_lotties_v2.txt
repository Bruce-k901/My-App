
Lottie Pack v2 — Upgraded
Date: 2025-11-07

Replaced files (drop-in, same names)
- danger_zone_dial.json  — ticks, eased needle, caption pulse
- storage_hierarchy.json — sliding trays with labels, drip path demo

How to deploy
1) Copy JSON into /public/lottie/ overwriting v1.
2) No code changes needed if you used the wrapper + paths.
3) Loop off for both.

QA notes
- 1200x800, 30fps, lightweight layers.
