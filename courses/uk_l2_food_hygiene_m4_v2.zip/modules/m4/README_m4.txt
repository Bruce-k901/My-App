
Module 4 — Personal Hygiene & PPE
Date: 2025-11-08
Duration: ~15 minutes
Interactivity: Lottie handwashing, sequencer, hotspot, branch scenario, quiz

Media:
- lottie/handwash_steps.json
- images/hands_touchpoints.png (placeholder workstation image)

Components used:
- HandwashSequencer
- HotspotRoom
- BranchScenario

Add "m4" to the course sequence.
Outcomes map to L2-4.1..L2-4.5.
