
Lottie Pack v1 — Food Hygiene
Date: 2025-11-07

Files
- danger_zone_dial.json
- handwash_steps.json
- storage_hierarchy.json
- cleaning_cycle.json
- cross_contact.json

Usage
- Load with lottie-react or similar.
- Recommended size 1200x800; scale with CSS.
- Loop off for gauge and storage. Loop on for cleaning cycle if desired.

Example:
  <Player autoplay loop={false} src='/lottie/danger_zone_dial.json' />
